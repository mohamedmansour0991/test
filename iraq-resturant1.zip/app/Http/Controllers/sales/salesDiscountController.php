<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class salesDiscountController extends Controller
{

  public function index()
  {
    return view('reborts.salesDiscount');
  }
  public function day(Request $request)
  {
    $day = [Carbon::today(), Carbon::today()];
    $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
    $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
    $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
    $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
    $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

    if (!empty($request->filter)) {

      $time = $request->filter;
      if ($request->filter == "day") {
        $time = $day;
      } elseif ($request->filter == "yesterday") {
        $time = $yesterday;
      } elseif ($request->filter == "week") {
        $time = $week;
      } elseif ($request->filter == "month") {
        $time = $month;
      } elseif (!empty($request->startDate) && !empty($request->endDate)) {
        $time = $date;
      } elseif ($request->filter == "year") {
        $time = $year;
      }
    } else {
      $time = $day;
    }
    $results = DB::table('AR_SalesInvoice_Main as m')
      ->selectRaw("
          m.[InvoiceNo],
          CONVERT(date, m.[InvoiceDate], 23) As InvoiceDate,
          CAST(m.[TotalInvoice] AS float) AS [TotalInvoice],
          CAST(m.[paid] AS float) AS [paid],
          CAST(m.[Residual] AS float) AS [Residual],
          CAST(m.[Discount] AS float) AS [Discount],
          CAST(m.[TotalInvoiceAfterDiscount] AS float) AS [TotalInvoiceAfterDiscount],
          m.[DiscountResion],
          m.extra,
          ROW_NUMBER() OVER (ORDER BY m.[InvoiceNo]) AS rn,
          CASE WHEN RS_DiscountType.ID IS NULL THEN 'خصم عام' ELSE RS_DiscountType.NameAr END AS DiscountType,
          u.UserName
      ")
      ->leftJoin('RS_DiscountType', 'm.dilvery_type', '=', 'RS_DiscountType.ID')
      ->join('Main_Users as u', 'm.UserID', '=', 'u.ID')
      ->where('m.Discount', '>', 0)
      ->whereBetween(DB::raw("CONVERT(date, m.[InvoiceDate], 23)"), $time)
      ->unionAll(
        DB::table('AR_SalesInvoice_Main as m')
          ->selectRaw("
                  m.[InvoiceNo],
                  CONVERT(date, m.[InvoiceDate], 23) As InvoiceDate,
                  CAST(d.Total AS float) AS [TotalInvoice],
                  CAST(m.[paid] AS float) AS [paid],
                  CAST(m.[Residual] AS float) AS [Residual],
                  CAST(d.[Discount] AS float) AS [Discount],
                  CAST(d.TotalAfterDiscount AS float) AS TotalAfterDiscount,
                  m.[DiscountResion],
                  m.extra,
                  ROW_NUMBER() OVER (ORDER BY m.[InvoiceNo]) AS rn,
                  CASE WHEN RS_DiscountType.ID IS NULL THEN 'خصم عام' ELSE RS_DiscountType.NameAr END AS DiscountType,
                  u.UserName
              ")
          ->join('AR_SalesInvoice_Details as d', 'm.ID', '=', 'd.MainID')
          ->leftJoin('RS_DiscountType', 'm.dilvery_type', '=', 'RS_DiscountType.ID')
          ->join('Main_Users as u', 'm.UserID', '=', 'u.ID')
          ->where('d.Discount', '>', 0)
        ->whereBetween(DB::raw("CONVERT(date, m.[InvoiceDate], 23)"), $time)
      )
      ->get();


    return DataTables($results)
      ->addIndexColumn()
      ->make(true);
  }
}
