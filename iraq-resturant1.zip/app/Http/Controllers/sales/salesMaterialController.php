<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class salesMaterialController extends Controller
{



    public function index()
    {
        return view('reborts.salesMaterial');
    }


    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }

        $results = DB::table(DB::raw('(
            SELECT	ItemName,
                SUM(CAST(Quantity AS FLOAT)) AS Quantity,
                SUM(CAST(Total AS FLOAT)) AS Total,
                COUNT(invoID) AS amount,
                MAX(UserName) AS UserName,
                GroupName,
                OrderTypeName,
                CAST(Price AS FLOAT) AS Price,
                InvoiceDate 
            FROM (
                SELECT	CASE WHEN d.ItemSizeID > 0 THEN CONCAT(i.NameAr COLLATE SQL_Latin1_General_CP1_CS_AS, \' ( \', sp.SizeName, \' )\') ELSE i.NameAr END AS ItemName,
                    CAST(d.Quantity AS FLOAT) AS Quantity,
                    d.Price,
                    CAST(d.Price * d.Quantity AS FLOAT) AS Total,
                    CAST(CASE WHEN n.TypeID = 1 THEN 0 ELSE 1 END AS BIT) AS IsDecimal,
                    u.UserName,
                    \'مبيعات\' AS TrxType,
                    m.RSTableID,
                    m.IsDelivery,
                    CASE	WHEN RSTableID IS NOT NULL THEN \'طاولة\'
                        WHEN RSTableID IS NULL AND IsDelivery = 1 THEN \'ديلفري\'
                        WHEN RSTableID IS NULL AND IsDelivery = 0 THEN \'سفري\'
                    END AS OrderTypeName,
                    InvoiceDate ,
                    SC_ItemsGroups.NameAr as GroupName,
                    m.ID as invoID
                FROM	AR_SalesInvoice_Main m
                    INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
                    INNER JOIN Main_Users u ON u.ID = m.UserID
                    INNER JOIN SC_Items i ON i.ID = d.ItemID
                    INNER JOIN SC_ItemsGroups on i.ItemGroupID = SC_ItemsGroups.ID
                    INNER JOIN SC_MeasurementUnits n ON n.ID = d.UnitID
                    LEFT OUTER JOIN SC_Items_SizePrice sp ON sp.ID = d.ItemSizeID
                where
                    m.IsTemp = 0
                    AND m.IsOfferPrice = 0
                    AND m.IsGift = 0
            ) tbl
            group by ItemName, GroupName, Price, OrderTypeName,InvoiceDate
        ) AS subquery'))
            ->whereBetween(DB::raw("CONVERT(date, InvoiceDate, 23)"), $time)
            ->get();

        return DataTables($results)
            ->addIndexColumn()
            ->make(true);
    }
}
