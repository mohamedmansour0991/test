<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class DeliveryReportController extends Controller
{

    public function index()
    {
        return view('reborts.deliveryReport');
    }
    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }
        $results = DB::select("
    SELECT
        COUNT(*) AS amount,
        u1.NameAr,
        u1.ID,
        CAST(SUM(TotalInvoice) AS float) AS TotalInvoice,
        CAST(SUM(Discount) AS float) AS Discount,
        CAST(SUM(Fess) AS float) AS Fess,
        CAST(SUM(TotalInvoiceAfterDiscount) - SUM(ISNULL(Fess, 0)) AS float) AS TotalInvoiceAfterDiscount
    FROM [dbo].[AR_SalesInvoice_Main]
    LEFT JOIN RS_DeliveryDrivers u1 ON u1.ID = DeliveryDriverID
    WHERE IsTemp = 0
        AND IsDelivery = 1
        AND DeliveryDriverID > 0
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY u1.NameAr, u1.ID
    ", [$time[0], $time[1]]);

        return DataTables($results)
            ->addIndexColumn()
            ->make(true);
    }
}
