<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class CompanyController extends Controller
{


    public function index()
    {
        return view('reborts.company');
    }

    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
    $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
    $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
    $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
    $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
    $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

    if (!empty($request->filter)) {

      $time = $request->filter;
      if ($request->filter == "day") {
        $time = $day;
      } elseif ($request->filter == "yesterday") {
        $time = $yesterday;
      } elseif ($request->filter == "week") {
        $time = $week;
      } elseif ($request->filter == "month") {
        $time = $month;
      } elseif (!empty($request->startDate) && !empty($request->endDate)) {
        $time = $date;
      } elseif ($request->filter == "year") {
        $time = $year;
      }
    } else {
      $time = $day;
    }
    $results = DB::select("
    SELECT
        COUNT([AR_SalesInvoice_Main].[ID]) AS amount,
        SUM([TotalInvoiceAfterDiscount]) AS total,
        RS_DiscountType.NameAr AS delivery_type
    FROM [dbo].[AR_SalesInvoice_Main]
    LEFT JOIN RS_DiscountType ON dilvery_type = RS_DiscountType.ID
    WHERE IsTemp = 0
        AND IsOfferPrice = 0
        AND RS_DiscountType.NameAr IS NOT NULL
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY RS_DiscountType.NameAr
", [$time[0], $time[1]]);


    
        return DataTables($results)
            ->addIndexColumn()
            ->make(true);
    }
}
