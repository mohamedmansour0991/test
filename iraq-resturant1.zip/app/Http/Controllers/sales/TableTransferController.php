<?php

namespace App\Http\Controllers\sales;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class TableTransferController extends Controller
{
    public function day(){

        $results = DB::select("
        SELECT
            dbo.RS_ItemChange.ChangeDate,
            tb.NameAr AS TableNo,
            floors.NameAr AS FloorNumber,
            CONVERT(NVARCHAR, CAST(ChangeDate AS TIME), 100) AS Deleted_time,
            dbo.Main_Users.UserName AS captain
        FROM RS_ItemChange
        INNER JOIN dbo.RS_RestaurantTables tb ON dbo.RS_ItemChange.SourceTabelID = tb.ID
        INNER JOIN dbo.RS_RestaurantTables floors ON RS_ItemChange.TargetTabelID = floors.ID
        INNER JOIN dbo.Main_Users ON dbo.RS_ItemChange.CashierID = dbo.Main_Users.ID
    ");
    
        
                    // return   $results ;
                return view('reborts.tableTransfer',compact('results'));
            }
}
