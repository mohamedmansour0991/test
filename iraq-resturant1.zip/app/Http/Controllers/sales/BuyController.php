<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Contracts\DataTable;
use Yajra\DataTables\Facades\DataTables;

class BuyController extends Controller
{

    public function index()
    {
        return view('reborts.buy');
    }
    public function day(Request $request)
    {
        $day = [Carbon::today(),Carbon::today()] ;
        $yesterday =  [Carbon::yesterday(),Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate ) && !empty($request->endDate)  ) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }
// return $date ; 
        $results = DB::table('CM_SafeTrxs_Main as m')
            ->select([
                'fd.NameAr as TrxTypeName',
                'm.TrxNo',
                DB::raw("CONVERT(date, m.TrxDate, 23) as TrxDate "),
                'a.NameAr as AccountName',
                'm.Note',
                'd.Value',
                'c.NameAr as CurrencyName',
                DB::raw('ROW_NUMBER() OVER (ORDER BY a.NameAr) as rn'),
                'm.ID',
            ])
            ->join('CM_SafeTrxs_Details as d', 'd.MainID', '=', 'm.ID')
            ->join('GL_ChartOfAccount as a', 'a.ID', '=', 'm.AccountID')
            ->join('Main_FastDefinitions_Details as fd', function ($join) {
                $join->on('fd.DefinitionID', '=', 'm.fdTrxType')
                    ->on('fd.ID', '=', 'm.TrxTypeID');
            })
            ->join('Main_IncomeAndExpenses', function ($join) {
                $join->on('m.AccountID', '=', 'Main_IncomeAndExpenses.AccountID')
                    ->where('Main_IncomeAndExpenses.IsExpenses', 1);
            })
            ->join('CM_Currency as c', 'c.ID', '=', 'd.CurrencyID')
            ->where('d.Value', '>', 0)
            ->whereBetween(DB::raw("CONVERT(date, m.TrxDate, 23)"), $time)
            ->orderBy('rn')
            ->orderBy('m.TrxDate')
            ->get();

        return DataTables($results)
            ->make(true);
    }
}
