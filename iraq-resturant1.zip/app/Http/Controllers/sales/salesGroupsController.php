<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class salesGroupsController extends Controller
{

    public function index(){
        return view('reborts.salesGroups');
    }
    public function day(Request $request)
    {
        // Define date ranges based on user input or defaults
        $day = [Carbon::today(), Carbon::today()];
        $yesterday = [Carbon::yesterday(), Carbon::yesterday()];
        $week = [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month = [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year = [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date = [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];
    
        // Determine the time range based on user input
        if (!empty($request->filter)) {
            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $year;
        }
    
        // Your SQL query
        $results = DB::table('AR_SalesInvoice_Main AS m')
            ->join('AR_SalesInvoice_Details AS d', 'm.ID', '=', 'd.MainID')
            ->join('Main_Users AS u', 'u.ID', '=', 'm.UserID')
            ->join('SC_Items AS i', 'i.ID', '=', 'd.ItemID')
            ->join('SC_ItemsGroups AS g', 'g.ID', '=', 'i.ItemGroupID')
            ->where('m.IsTemp', 0)
            ->where('m.IsOfferPrice', 0)
            ->whereNull('m.ExpincesID')
            ->whereBetween(DB::raw('CONVERT(date, m.InvoiceDate, 23)'), $time)
            ->groupBy('g.NameAr')
            ->select(
                'g.NameAr AS GroupName',
                DB::raw('SUM(d.TotalAfterDiscount) AS TotalInvoiceAfterDiscount'),
                DB::raw('SUM(d.Quantity) AS Quantity')
            )
            ->get();
    
        // Calculate the Percentage
        $totalInvoiceAfterDiscountSum = $results->sum('TotalInvoiceAfterDiscount');
        $results->transform(function ($item) use ($totalInvoiceAfterDiscountSum) {
            $item->Percentage = round(($item->TotalInvoiceAfterDiscount / $totalInvoiceAfterDiscountSum) * 100, 2);
            return $item;
        });
    
        return DataTables($results)
            ->addIndexColumn()
            ->make(true);
    }
    
}
