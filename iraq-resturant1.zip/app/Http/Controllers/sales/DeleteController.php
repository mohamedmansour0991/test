<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class DeleteController extends Controller
{

public function index(){
    return view('reborts.delete');
}

    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }

        $results = DB::table('RS_DeletedItem')
        ->selectRaw("
            DISTINCT [Invo_number] AS Invo_number,
            ROW_NUMBER() OVER (ORDER BY [Invo_number]) AS rn,
            CONVERT(date, [Invo_date], 23) AS Invo_date,
            SC_Items.NameAr AS NameAr,
            CAST([Qty] AS float) AS Qty,
            CAST([Invo_total] AS float) AS Invo_total,
            CAST([Item_total] AS float) AS Item_total,
            CAST([Qty] * [Item_total] AS float) AS Total,
            [Delete_Resion] AS Delete_Resion,
            [Notes] AS Notes,
            aa.NameAr AS tableanme,
            bb.NameAr AS branshNAme,
            u.UserName AS UserName,
            LTRIM(RIGHT(CONVERT(VARCHAR(20), [DeletedTime], 100), 7)) AS DeletTime,
            LTRIM(RIGHT(CONVERT(VARCHAR(20), [Invo_date], 100), 7)) AS PrintTime,
            u1.UserName AS DeleteName
        ")
        ->join('SC_Items', 'RS_DeletedItem.Item_code', '=', 'SC_Items.ID')
        ->leftJoin('RS_RestaurantTables AS aa', 'RS_DeletedItem.table_number', '=', 'aa.ID')
        ->leftJoin('RS_RestaurantTables AS bb', 'RS_DeletedItem.bransh', '=', 'bb.ID')
        ->join('Main_Users AS u', 'u.ID', '=', 'UserId')
        ->join('Main_Users AS u1', 'u1.ID', '=', 'RS_DeletedItem.UserId')
        ->whereBetween(DB::raw("CONVERT(date, [Invo_date], 23)"), $time)
        ->get();
    
    
    return DataTables($results)
    ->addIndexColumn()
    ->make(true);

 
    }
}
