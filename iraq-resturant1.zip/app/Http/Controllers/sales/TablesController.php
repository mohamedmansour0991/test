<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class TablesController extends Controller
{

    public function index()
    {
        return view('reborts.tables');
    }
    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }
        $results = DB::select("
    SELECT
        COUNT(DISTINCT RS_RestaurantTables.ID) AS amount,
        CAST(ISNULL(SUM(AR_SalesInvoice_Details.Price * AR_SalesInvoice_Details.Quantity), 0) AS float) AS total,
        CASE
            WHEN [Status] = 3 THEN 'طلب وصل الحساب'
            WHEN [Status] = 2 THEN 'مفتوحة'
        END AS Status
    FROM [dbo].[RS_RestaurantTables]
    LEFT JOIN AR_SalesInvoice_Main ON RS_RestaurantTables.ID = AR_SalesInvoice_Main.RSTableID
    LEFT JOIN AR_SalesInvoice_Details ON AR_SalesInvoice_Main.ID = AR_SalesInvoice_Details.MainID
    WHERE Status <> 1 AND IsTable = 1 AND IsTemp = 1 
    AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY [Status]

    UNION

    SELECT
        COUNT(id) AS amount,
        CAST(0 AS float) AS total,
        'الفارغة' AS Status
    FROM [RS_RestaurantTables]
    WHERE IsTable = 1 AND Status = 1
    ", [$time[0], $time[1]]);


        return DataTables($results)
            ->addIndexColumn()
            ->make(true);
    }
}
