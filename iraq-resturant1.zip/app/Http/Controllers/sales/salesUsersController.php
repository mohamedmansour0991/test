<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class salesUsersController extends Controller
{

    public function index()
    {
        return view('reborts.users');
    }
    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];
        if (!empty($request->filter)) {
            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }
        $startDate = Carbon::now()->startOfMonth()->format('Y-m-d');
        $endDate = Carbon::now()->endOfMonth()->format('Y-m-d');
        $userID = 0;
        $ignoreTime = 1; // You can set this to 0 if needed
        $shiftID = 0;
        //-------------------------------##Open---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##Open') IS NOT NULL
            DROP TABLE ##Open;
    
        CREATE TABLE ##Open (
            UserName NVARCHAR(255),
            OpenMony FLOAT
        );
    
        INSERT INTO ##Open (UserName, OpenMony)
        SELECT u.UserName, SUM(ISNULL(OpenMony, 0))
        FROM [dbo].[RS_Shifts] m
        INNER JOIN Main_Users u ON u.ID = m.CreateUserID
        WHERE CONVERT(date, [StartDate], 23) BETWEEN ? AND ?
        GROUP BY u.UserName;
    ", [$time[0], $time[1]]);
    
        //-------------------------------##sales---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##sales') IS NOT NULL
            DROP TABLE ##sales;
    
        CREATE TABLE ##sales (
            UserName NVARCHAR(255),
            TotalSales FLOAT
        );
    
        INSERT INTO ##sales (UserName, TotalSales)
        SELECT UserName, SUM(CAST((d.Price * d.Quantity) AS FLOAT))
        FROM AR_SalesInvoice_Main m
        INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
        INNER JOIN Main_Users u ON u.ID = m.UserID
        WHERE m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND m.MoneyRecipientUserID IS NULL
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        GROUP BY UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##Safery---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##Safery') IS NOT NULL
            DROP TABLE ##Safery;
    
        CREATE TABLE ##Safery (
            UserName NVARCHAR(255),
            Total FLOAT
        );
    
        INSERT INTO ##Safery (UserName, Total)
        SELECT u.UserName, SUM(ISNULL(CAST((d.Price * d.Quantity) AS FLOAT), 0))
        FROM AR_SalesInvoice_Main m
        INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
        INNER JOIN Main_Users u ON u.ID = m.UserID
        WHERE m.IsTemp = 0
        AND m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        AND (m.RSTableID IS NULL AND m.IsDelivery = 0)
        GROUP BY u.UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##SaferyNO---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##SaferyNO') IS NOT NULL
            DROP TABLE ##SaferyNO;
    
        CREATE TABLE ##SaferyNO (
            UserName NVARCHAR(255),
            No INT
        );
    
        INSERT INTO ##SaferyNO (UserName, No)
        SELECT u.UserName, COUNT(*)
        FROM AR_SalesInvoice_Main m
        INNER JOIN Main_Users u ON u.ID = m.UserID
        WHERE m.IsTemp = 0
        AND m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        AND (m.RSTableID IS NULL AND m.IsDelivery = 0)
        GROUP BY u.UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##tabel---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##tabel') IS NOT NULL
            DROP TABLE ##tabel;
    
        CREATE TABLE ##tabel (
            UserName NVARCHAR(255),
            Total FLOAT
        );
    
        INSERT INTO ##tabel (UserName, Total)
        SELECT u.UserName, SUM(ISNULL(CAST((d.Quantity * d.Price) AS FLOAT), 0))
        FROM AR_SalesInvoice_Main m
        INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
        INNER JOIN Main_Users u ON u.ID = m.MoneyRecipientUserID
        WHERE m.IsTemp = 0
        AND m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND m.RSTableID IS NOT NULL
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        GROUP BY u.UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##tabelNO---------------------------------

        DB::statement("
    IF OBJECT_ID('tempdb..##tabelNO') IS NOT NULL
        DROP TABLE ##tabelNO;

    CREATE TABLE ##tabelNO (
        UserName NVARCHAR(255),
        No INT
    );

    INSERT INTO ##tabelNO (UserName, No)
    SELECT u.UserName, COUNT(*)
    FROM AR_SalesInvoice_Main m
    INNER JOIN Main_Users u ON u.ID = m.MoneyRecipientUserID
    WHERE m.IsTemp = 0
    AND m.IsOfferPrice = 0
    AND m.IsGift = 0
    AND m.RSTableID IS NOT NULL
    AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);
        //-------------------------------##delivery---------------------------------

        DB::statement("
        IF OBJECT_ID('tempdb..##delivery') IS NOT NULL
            DROP TABLE ##delivery;
    
        CREATE TABLE ##delivery (
            UserName NVARCHAR(255),
            Total FLOAT
        );
    
        INSERT INTO ##delivery (UserName, Total)
        SELECT u.UserName, SUM(ISNULL(CAST((d.Price * d.Quantity) AS FLOAT), 0))
        FROM AR_SalesInvoice_Main m
        INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
        INNER JOIN Main_Users u ON u.ID = m.UserID
        WHERE m.IsTemp = 0
        AND m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND m.RSTableID IS NULL
        AND m.IsDelivery = 1
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        GROUP BY u.UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##dliveryNO---------------------------------
        DB::statement("
        IF OBJECT_ID('tempdb..##dliveryNO') IS NOT NULL
            DROP TABLE ##dliveryNO;
    
        CREATE TABLE ##dliveryNO (
            UserName NVARCHAR(255),
            No INT
        );
    
        INSERT INTO ##dliveryNO (UserName, No)
        SELECT u.UserName, COUNT(*)
        FROM AR_SalesInvoice_Main m
        INNER JOIN Main_Users u ON u.ID = m.UserID
        WHERE m.IsTemp = 0
        AND m.IsOfferPrice = 0
        AND m.IsGift = 0
        AND m.RSTableID IS NULL
        AND m.IsDelivery = 1
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        GROUP BY u.UserName;
        ", [$time[0], $time[1]]);
        //-------------------------------##Expences---------------------------------

        DB::statement("
    IF OBJECT_ID('tempdb..##Expences') IS NOT NULL
        DROP TABLE ##Expences;

    CREATE TABLE ##Expences (
        ExpencValue FLOAT,
        UserName NVARCHAR(255)
    );

    INSERT INTO ##Expences (ExpencValue, UserName)
    SELECT CAST(SUM(d.Value) AS FLOAT) AS ExpencValue, u.UserName
    FROM CM_SafeTrxs_Main m
    INNER JOIN CM_SafeTrxs_Details d ON d.MainID = m.ID
    INNER JOIN Main_Users u ON u.ID = m.UserID
    INNER JOIN GL_ChartOfAccount a ON a.ID = m.AccountID
    INNER JOIN Main_FastDefinitions_Details fd ON fd.DefinitionID = m.fdTrxType AND fd.ID = m.TrxTypeID
    INNER JOIN CM_Currency c ON c.ID = d.CurrencyID
    WHERE d.Value > 0
    AND ISNULL(d.Commision, 0) = 0
    AND m.TrxTypeID = 1
    AND CONVERT(date, [TrxDate], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);
        //-------------------------------##discount---------------------------------
        DB::statement("
    IF OBJECT_ID('tempdb..##discount') IS NOT NULL
        DROP TABLE ##discount;

    CREATE TABLE ##discount (
        Discount FLOAT,
        UserName NVARCHAR(255)
    );

    INSERT INTO ##discount (Discount, UserName)
    SELECT CAST(SUM(m.Discount) AS FLOAT) AS Discount, u.UserName
    FROM AR_SalesInvoice_Main m
    INNER JOIN Main_Users u ON u.ID = m.UserID
    WHERE m.IsOfferPrice = 0
    AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);

        //-------------------------------##discount2---------------------------------
        DB::statement("
    IF OBJECT_ID('tempdb..##discount2') IS NOT NULL
        DROP TABLE ##discount2;

    CREATE TABLE ##discount2 (
        Discount FLOAT,
        UserName NVARCHAR(255)
    );

    INSERT INTO ##discount2 (Discount, UserName)
    SELECT CAST(SUM(d.Discount) AS FLOAT) AS Discount, u.UserName
    FROM AR_SalesInvoice_Main m
    INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
    INNER JOIN Main_Users u ON u.ID = m.UserID
    WHERE d.Discount > 0
    AND m.IsOfferPrice = 0
    AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);

        //-------------------------------##salesGift---------------------------------
        DB::statement("
    IF OBJECT_ID('tempdb..##salesGift') IS NOT NULL
        DROP TABLE ##salesGift;

    CREATE TABLE ##salesGift (
        UserName NVARCHAR(255),
        TotalSalesGift FLOAT
    );

    INSERT INTO ##salesGift (UserName, TotalSalesGift)
    SELECT u.UserName, SUM(CAST((d.Price * d.Quantity) AS FLOAT))
    FROM AR_SalesInvoice_Main m
    INNER JOIN AR_SalesInvoice_Details d ON m.ID = d.MainID
    INNER JOIN Main_Users u ON u.ID = m.UserID
    WHERE m.IsGift = 1
    AND m.IsOfferPrice = 0
    AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);

        //-------------------------------##delete---------------------------------
        DB::statement("
    IF OBJECT_ID('tempdb..##delete') IS NOT NULL
        DROP TABLE ##delete;

    CREATE TABLE ##delete (
        TotalDelete FLOAT,
        UserName NVARCHAR(255)
    );

    INSERT INTO ##delete (TotalDelete, UserName)
    SELECT CAST(SUM([Qty] * [Item_total]) AS FLOAT) AS TotalDelete, u.UserName
    FROM [dbo].[RS_DeletedItem]
    INNER JOIN Main_Users u ON u.ID = UserId
    AND CONVERT(date, [Invo_date], 23) BETWEEN ? AND ?
    GROUP BY u.UserName;
    ", [$time[0], $time[1]]);
        //-------------------------------All---------------------------------
        $userData1 = DB::table('Main_Users as u')
        ->select(
            'u.UserName',
            'OpenMony',
            'TotalSalesGift',
            DB::raw('ISNULL(TotalSales, 0) + ISNULL(OpenMony, 0) + ISNULL(##Safery.Total, 0) + ISNULL(##tabel.Total, 0) + ISNULL(##delivery.Total, 0) as TotalSales'),
            '##Safery.Total as TotalSafery',
            '##SaferyNO.No as NoSafery',
            '##tabelNO.No as NoTabel',
            '##tabel.Total as TotalTabel',
            '##dliveryNO.No as NoDlivery',
            '##delivery.Total as TotalDlivery',
            DB::raw('ISNULL(##discount.Discount, 0) + ISNULL(##discount2.Discount, 0) as Discount'),
            '##Expences.ExpencValue',
            DB::raw('ISNULL(OpenMony, 0) + ISNULL(##Safery.Total, 0) + ISNULL(##tabel.Total, 0) + ISNULL(##delivery.Total, 0) - ISNULL(##discount.Discount, 0) - ISNULL(##discount2.Discount, 0) - ISNULL(##Expences.ExpencValue, 0) as net')
        )
        ->where('UserType', '<>', 1)
        ->leftJoin('##Safery', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##Safery.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##SaferyNO', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##SaferyNO.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##delivery', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##delivery.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##dliveryNO', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##dliveryNO.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##delete', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##delete.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##tabel', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##tabel.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##tabelNO', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##tabelNO.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##discount', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##discount.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##discount2', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##discount2.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##Expences', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##Expences.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##sales', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##sales.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##Open', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##Open.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->leftJoin('##salesGift', function ($join) {
            $join->on('u.UserName', '=', DB::raw('##salesGift.UserName COLLATE SQL_Latin1_General_CP1_CI_AS'));
        })
        ->get();
    


        DB::statement("DROP TABLE ##discount");
        DB::statement("DROP TABLE ##Expences");
        DB::statement("DROP TABLE ##Safery");
        DB::statement("DROP TABLE ##tabel");
        DB::statement("DROP TABLE ##delivery");
        DB::statement("DROP TABLE ##sales");
        DB::statement("DROP TABLE ##Open");
        DB::statement("DROP TABLE ##delete");
        DB::statement("DROP TABLE ##salesGift");
        DB::statement("DROP TABLE ##discount2");
        DB::statement("DROP TABLE ##dliveryNO");
        DB::statement("DROP TABLE ##SaferyNO");
        DB::statement("DROP TABLE ##tabelNO");


        $totalValue = $userData1->sum('Value');

        return DataTables($userData1)
            ->addIndexColumn()
            ->make(true);
    }
}
