<?php

namespace App\Http\Controllers\sales;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class InviteController extends Controller
{
    public function index(){
        return view('reborts.invite');
    }
    public function day(Request $request)
    {
        $day = [Carbon::today(), Carbon::today()];
        $yesterday =  [Carbon::yesterday(), Carbon::yesterday()];
        $week =   [Carbon::parse(now()->startOfWeek()), Carbon::parse(now()->endOfWeek())];
        $month =  [Carbon::parse(now()->startOfMonth()), Carbon::parse(now()->endOfMonth())];
        $year =  [Carbon::parse(now()->startOfYear()), Carbon::parse(now()->endOfYear())];
        $date =  [Carbon::parse($request->startDate), Carbon::parse($request->endDate)];

        if (!empty($request->filter)) {

            $time = $request->filter;
            if ($request->filter == "day") {
                $time = $day;
            } elseif ($request->filter == "yesterday") {
                $time = $yesterday;
            } elseif ($request->filter == "week") {
                $time = $week;
            } elseif ($request->filter == "month") {
                $time = $month;
            } elseif (!empty($request->startDate) && !empty($request->endDate)) {
                $time = $date;
            } elseif ($request->filter == "year") {
                $time = $year;
            }
        } else {
            $time = $day;
        }
        $results = DB::select("
        SELECT
            m.[InvoiceNo],
            CONVERT(date, [InvoiceDate], 23) As InvoiceDate ,
            CAST(m.[TotalInvoice] AS float) AS TotalInvoice,
            CAST(m.[paid] AS float) AS paid,
            CAST(m.[Residual] AS float) AS Residual,
            CAST(m.[Discount] AS float) AS Discount,
            CAST(m.[TotalInvoiceAfterDiscount] AS float) AS TotalInvoiceAfterDiscount,
            ROW_NUMBER() OVER (ORDER BY m.[InvoiceNo]) AS rn,
            m.extra,
            m.Notie1 AS Notie1
        FROM [dbo].[AR_SalesInvoice_Main] m
        WHERE IsGift = 1
        AND CONVERT(date, [InvoiceDate], 23) BETWEEN ? AND ?
        ", [$time[0], $time[1]]);

        return DataTables($results)
        ->addIndexColumn()
        ->make(true);
    }
}
