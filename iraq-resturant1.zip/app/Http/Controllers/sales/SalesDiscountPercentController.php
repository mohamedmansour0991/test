<?php

namespace App\Http\Controllers\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SalesDiscountPercentController extends Controller
{
    public function day(){


        $results = DB::select("
            SELECT SUM(m.TotalInvoice) AS TotalInvoice, SUM(m.Discount) AS Discount, m.strDicount
            FROM [dbo].[AR_SalesInvoice_Main] m
            WHERE m.IsTemp = 0
            AND m.IsOfferPrice = 0
            AND m.IsGift = 0
            AND m.strDicount IS NOT NULL
            AND m.dilvery_type = 0
            GROUP BY m.strDicount
        ");
        
 
        return view('reborts.SalesDiscountPercent', compact('results'));

    }
}
