@extends('layouts.master')
@section('content')

<div id="main">
    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Navs</h3>
                    <p class="text-subtitle text-muted">Examples for how to use Bootstrap’s included navigation
                        components.
                    </p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        z<ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Navs</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <section class="section">

            <div class="row">
                <div class="col-md-6 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Horizontal Navs</h5>
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home"
                                        role="tab" aria-controls="home" aria-selected="true">مبيعات المستخدمين</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile"
                                        role="tab" aria-controls="profile" aria-selected="false">مبيعات المجموعات</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact"
                                        role="tab" aria-controls="contact" aria-selected="false">مبيعات المواد</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="home-tab">
                                    <p class='my-2'>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                        Nulla ut nulla
                                        neque. Ut hendrerit nulla a euismod pretium.
                                        Fusce venenatis sagittis ex efficitur suscipit. In tempor mattis
                                        fringilla. Sed id
                                        tincidunt orci, et volutpat ligula.
                                        Aliquam sollicitudin sagittis ex, a rhoncus nisl feugiat quis. Lorem
                                        ipsum dolor sit
                                        amet, consectetur adipiscing elit.
                                        Nunc ultricies ligula a tempor vulputate. Suspendisse pretium mollis
                                        ultrices.</p>
                                </div>
                                <div class="tab-pane fade" id="profile" role="tabpanel"
                                    aria-labelledby="profile-tab">
                                    Integer interdum diam eleifend metus lacinia, quis gravida eros mollis.
                                    Fusce non sapien
                                    sit amet magna dapibus
                                    ultrices. Morbi tincidunt magna ex, eget faucibus sapien bibendum non. Duis
                                    a mauris ex.
                                    Ut finibus risus sed massa
                                    mattis porta. Aliquam sagittis massa et purus efficitur ultricies. Integer
                                    pretium dolor
                                    at sapien laoreet ultricies.
                                    Fusce congue et lorem id convallis. Nulla volutpat tellus nec molestie
                                    finibus. In nec
                                    odio tincidunt eros finibus
                                    ullamcorper. Ut sodales, dui nec posuere finibus, nisl sem aliquam metus, eu
                                    accumsan
                                    lacus felis at odio. Sed lacus
                                    quam, convallis quis condimentum ut, accumsan congue massa. Pellentesque et
                                    quam vel
                                    massa pretium ullamcorper vitae eu
                                    tortor.
                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel"
                                    aria-labelledby="contact-tab">
                                    <p class="mt-2">Duis ultrices purus non eros fermentum hendrerit. Aenean
                                        ornare interdum
                                        viverra. Sed ut odio velit. Aenean eu diam
                                        dictum nibh rhoncus mattis quis ac risus. Vivamus eu congue ipsum.
                                        Maecenas id
                                        sollicitudin ex. Cras in ex vestibulum,
                                        posuere orci at, sollicitudin purus. Morbi mollis elementum enim, in
                                        cursus sem
                                        placerat ut.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
    @include('layouts.footer')
    </div>

</div>
@endsection