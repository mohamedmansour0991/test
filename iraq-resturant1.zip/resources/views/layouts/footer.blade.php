<footer dir="rtl">
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start text-right">
            <p>{{ \Carbon\Carbon::now()->year }} &copy; الوافي</p>
        </div>
    </div>
</footer>
