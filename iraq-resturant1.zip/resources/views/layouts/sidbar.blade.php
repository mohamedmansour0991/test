<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                <div class="logo ">
                    <a href="{{ route('dashboard') }}" style="display: flex;">
                        <img src="{{ asset('icon.ico') }}" alt="Logo" srcset=""
                            style=" height:50px ; width: 50px; align-items: center;">
                        <h1>Alwafi</h1>
                    </a>
                </div>
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">القائمه</li>
            
                <li class="sidebar-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <a href="{{ route('dashboard') }}" class='sidebar-link'>
                        <i class="bi bi-grid-fill"></i>
                        <span>لوحة التحكم</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('sales.users.day') ? 'active' : '' }}">
                    <a href="{{ route('sales.users.day') }}" class='sidebar-link'>
                        <i class="bi bi-collection-fill"></i>
                        <span> مبيعات المستخدمين</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('sales.groups.day') ? 'active' : '' }}">
                    <a href="{{ route('sales.groups.day') }}" class='sidebar-link'>
                        <i class="bi bi-stack"></i>
                        <span>مبيعات المجموعات</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('sales.material.day') ? 'active' : '' }}">
                    <a href="{{ route('sales.material.day') }}" class='sidebar-link'>
                        <i class="bi bi-grid-1x2-fill"></i>
                        <span>مبيعات المواد</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('buy.day') ? 'active' : '' }}">
                    <a href="{{ route('buy.day') }}" class='sidebar-link'>
                        <i class="bi bi-grid-1x2-fill"></i>
                        <span>تقرير المصروفات</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('delete.day') ? 'active' : '' }}">
                    <a href="{{ route('delete.day') }}" class='sidebar-link'>
                        <i class="bi bi-hexagon-fill"></i>
                        <span> تقرير المحذوفات</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('sales.discount.day') ? 'active' : '' }}">
                    <a href="{{ route('sales.discount.day') }}" class='sidebar-link'>
                        <i class="bi bi-pen-fill"></i>
                        <span> تقرير الخصومات</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('sales.discount.percent.day') ? 'active' : '' }}">
                    <a href="{{ route('sales.discount.percent.day') }}" class='sidebar-link'>
                        <i class="bi bi-grid-1x2-fill"></i>
                        <span>تقرير نسب الخصم</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('company.delivery.day') ? 'active' : '' }}">
                    <a href="{{ route('company.delivery.day') }}" class='sidebar-link'>
                        <i class="bi bi-file-earmark-spreadsheet-fill"></i>
                        <span>مبيعات شركات التوصيل</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('delivery.report.day') ? 'active' : '' }}">
                    <a href="{{ route('delivery.report.day') }}" class='sidebar-link'>
                        <i class="bi bi-pentagon-fill"></i>
                        <span>تقرير مبيعات الدليفري</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('invite.day') ? 'active' : '' }}">
                    <a href="{{ route('invite.day') }}" class='sidebar-link'>
                        <i class="bi bi-egg-fill"></i>
                        <span>مبيعات الضيافه</span>
                    </a>
                </li>
            
                <li class="sidebar-item {{ request()->routeIs('tables.day') ? 'active' : '' }}">
                    <a href="{{ route('tables.day') }}" class='sidebar-link'>
                        <i class="bi bi-bar-chart-fill"></i>
                        <span>مبيعات الطاولات</span>
                    </a>
                </li>
            
                <li class="sidebar-item">
                    <a href="#" class='sidebar-link' onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="bi bi-file-earmark-medical-fill"></i>
                        <span>تسجيل الخروج</span>
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </li>
                
            </ul>
            
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>

                    {{-- 
    
    
                    <li class="sidebar-title">Forms &amp; Tables</li>
    
    
                    <li class="sidebar-title">Extra UI</li>
    
                          <li class="submenu-item">
                                <a href="{{ route('tables.transfer.day') }}">
                                    <i class="bi bi-bar-chart"></i> تقرير نقل مادة
                                </a>
                            </li> 
    
    
                    <li class="sidebar-item  ">
                        <a href="ui-file-uploader.html" class='sidebar-link'>
                            <i class="bi bi-cloud-arrow-up-fill"></i>
                            <span>File Uploader</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  has-sub">
                        <a href="#" class='sidebar-link'>
                            <i class="bi bi-map-fill"></i>
                            <span>Maps</span>
                        </a>
                        <ul class="submenu ">
                            <li class="submenu-item ">
                                <a href="ui-map-google-map.html">Google Map</a>
                            </li>
                            <li class="submenu-item ">
                                <a href="ui-map-jsvectormap.html">JS Vector Map</a>
                            </li>
                        </ul>
                    </li>
    
                    <li class="sidebar-title">Pages</li>
    
                    <li class="sidebar-item  ">
                        <a href="application-email.html" class='sidebar-link'>
                            <i class="bi bi-envelope-fill"></i>
                            <span>Email Application</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  ">
                        <a href="application-chat.html" class='sidebar-link'>
                            <i class="bi bi-chat-dots-fill"></i>
                            <span>Chat Application</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  ">
                        <a href="application-gallery.html" class='sidebar-link'>
                            <i class="bi bi-image-fill"></i>
                            <span>Photo Gallery</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  ">
                        <a href="application-checkout.html" class='sidebar-link'>
                            <i class="bi bi-basket-fill"></i>
                            <span>Checkout Page</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  has-sub">
                        <a href="#" class='sidebar-link'>
                            <i class="bi bi-person-badge-fill"></i>
                            <span>Authentication</span>
                        </a>
                        <ul class="submenu ">
                            <li class="submenu-item ">
                                <a href="auth-login.html">Login</a>
                            </li>
                            <li class="submenu-item ">
                                <a href="auth-register.html">Register</a>
                            </li>
                            <li class="submenu-item ">
                                <a href="auth-forgot-password.html">Forgot Password</a>
                            </li>
                        </ul>
                    </li>
    
                    <li class="sidebar-item  has-sub">
                        <a href="#" class='sidebar-link'>
                            <i class="bi bi-x-octagon-fill"></i>
                            <span>Errors</span>
                        </a>
                        <ul class="submenu ">
                            <li class="submenu-item ">
                                <a href="error-403.html">403</a>
                            </li>
                            <li class="submenu-item ">
                                <a href="error-404.html">404</a>
                            </li>
                            <li class="submenu-item ">
                                <a href="error-500.html">500</a>
                            </li>
                        </ul>
                    </li>
    
                    <li class="sidebar-title">Raise Support</li>
    
                    <li class="sidebar-item  ">
                        <a href="https://zuramai.github.io/mazer/docs" class='sidebar-link'>
                            <i class="bi bi-life-preserver"></i>
                            <span>Documentation</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  ">
                        <a href="https://github.com/zuramai/mazer/blob/main/CONTRIBUTING.md" class='sidebar-link'>
                            <i class="bi bi-puzzle"></i>
                            <span>Contribute</span>
                        </a>
                    </li>
    
                    <li class="sidebar-item  ">
                        <a href="https://github.com/zuramai/mazer#donate" class='sidebar-link'>
                            <i class="bi bi-cash"></i>
                            <span>Donate</span>
                        </a>
                    </li> --}}