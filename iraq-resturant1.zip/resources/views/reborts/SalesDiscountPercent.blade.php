@extends('layouts.master')
@section('content')
    <div id="main">
        <header class="mb-3">
            <a href="#" class="burger-btn d-block d-xl-none">
                <i class="bi bi-justify fs-3"></i>
            </a>
        </header>

        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-2 order-last ">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">تقرير نسبة الخصم</li>
                                <li class="breadcrumb-item active" aria-current="page">التقارير</li>
                                <li class="breadcrumb-item"><a href="index.html">لوحة التحكم</a></li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-12 col-md-6 order-md-1 order-first">
                        <h3>تقرير نسبة الخصم</h3>

                    </div>
                </div>
            </div>
            <section class="section">
                <div class="card">
                    <div class="card-header">
                        تقرير نسبة الخصم
                    </div>

                    <div class="card-body">
                        <table id="table1" class="table table-striped dt-responsive  " style="width:100%">
                            <thead>
                                <thead class="thead_dark">
                                    {{-- <th> الاجمالي</th> --}}
                                    <th class="th_text">  نوع الخصم</th>
                                    <th class="th_text"> اجمالي الخصم</th>

                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($results as $sales)
                                <tr>

                                    {{-- <td>{{ number_format($sales->TotalInvoice, 2) }}</td> --}}
                                    <td>{{ $sales->strDicount; }}</td>
                                    <td>{{ number_format($sales->Discount, 2) }}</td>
                                </tr>
                                @empty
                                    no data 
                                @endforelse

                            </tbody>
                        </table>
                    </div>
                </div>

            </section>
        </div>

        @include('layouts.footer')
    </div>
@endsection
@section('datatable')
    <script src="assets/vendors/simple-datatables/simple-datatables.js"></script>
    <script>
        // Simple Datatable
        let table1 = document.querySelector('#table1');
        let dataTable = new simpleDatatables.DataTable(table1);
    </script>
@endsection
