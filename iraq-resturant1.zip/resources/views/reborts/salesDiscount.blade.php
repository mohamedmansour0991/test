@extends('layouts.master')
@section('content')
    <div id="main">
        <header class="mb-3">
            <a href="#" class="burger-btn d-block d-xl-none">
                <i class="bi bi-justify fs-3"></i>
            </a>
        </header>

        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-2 order-last ">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">تقرير الخصومات</li>
                                <li class="breadcrumb-item active" aria-current="page">التقارير</li>
                                <li class="breadcrumb-item"><a href="index.html">لوحة التحكم</a></li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-12 col-md-6 order-md-1 order-first">
                        <h3>تقرير الخصومات</h3>

                    </div>
                </div>
            </div>
            <div class="filters">
                <div>
                    <div class="btn" style="display: contents;" role="group" aria-label="Basic example">
                        <button class="filter-button  btn-sm btn-secondary" value="day">اليوم</button>
                        <button class="filter-button btn-sm  btn-secondary" value="yesterday">الامس</button>
                        <button class="filter-button btn-sm  btn-secondary" value="week">الاسبوع</button>
                        <button class="filter-button btn-sm  btn-secondary" value="month">الشهر </button>
                        <button class="filter-button btn-sm btn-secondary" value="year">السنه</button>
                    </div>
                </div>
            </div>
            <section class="section">
                <div class="card">
                    <div class="card-header">
                        تقرير الخصومات
                    </div>

                    <div class="card-body">
                        <table id="table5" class="table table-striped dt-responsive  " style="width:100%">
                            <thead>
                                <thead class="thead_dark">
                                    <th class="th_text"> #</th>
                                    <th class="th_text">اسم المستخدم</th>
                                    <th class="th_text"> رقم الفاتوره</th>
                                    <th class="th_text"> تاريخ الفاتوره</th>
                                    <th class="th_text"> الاجمالي</th>
                                    <th class="th_text"> مبلغ الخصم</th>
                                    <th class="th_text"> الصافي بعد الخصم</th>
                                    <th class="th_text"> سبب الخصم</th>
                                    <th class="th_text"> ملاحظات</th>
                                    </tr>
                                </thead>
                            <tbody>
                                {{-- @forelse ($results as $sales)
                                <tr>
                                    <td>{{ $sales->rn; }}</td>
                                    <td>{{ $sales->UserName; }}</td>
                                    <td>{{ $sales->InvoiceNo; }}</td>
                                    <td>{{ $sales->InvoiceDate; }}</td>
                                    <td>{{ number_format($sales->TotalInvoice, 2) }}</td>
                                    <td>{{ number_format($sales->Discount, 2) }}</td>
                                    <td>{{ $sales->DiscountType; }}</td>
                                    <td>{{ number_format($sales->Residual, 2) }}</td>
                                    <td>{{ $sales->DiscountResion; }}</td>
                                    <td>{{ $sales->extra; }}</td>
                                </tr>
                                @empty
                                    no data 
                                @endforelse --}}

                            </tbody>
                        </table>
                    </div>
                </div>

            </section>
        </div>

        @include('layouts.footer')
    </div>
@endsection
@section('datatable')
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
{{-- <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script> --}}
{{-- <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script> --}}
{{-- <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script> --}}
    <script>
        $(document).ready(function() {
            // Initialize the DataTable
            var table1 = $('#table5').DataTable({
                processing: true,
                serverSide: false,
                ajax: '/sales-discount-day', 
                scrollX: true,
                responsive: true,

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'UserName',
                        name: 'UserName'
                    },
                    {
                        data: 'InvoiceNo',
                        name: 'InvoiceNo'
                    },
                    {
                        data: 'InvoiceDate',
                        name: 'InvoiceDate'
                    },
                    {
                        data: 'TotalInvoice',
                        name: 'TotalInvoice'
                    },
                    {
                        data: 'Discount',
                        name: 'Discount'
                    },
                    {
                        data: 'Residual',
                        name: 'Residual'
                    },
                    {
                        data: 'DiscountResion',
                        name: 'DiscountResion'
                    },
                    {
                        data: 'extra',
                        name: 'extra'
                    }
                ],
                lengthMenu: [
                    [5, 10, 25, -1],
                    [5, 10, 25, "All"]
                ],
                pageLength: 10,
                language: {
                    processing: "جارٍ التحميل...",
                    lengthMenu: "أظهر _MENU_ مدخلات",
                    zeroRecords: "لم يعثر على أية سجلات",
                    info: "إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل",
                    infoEmpty: "يعرض 0 إلى 0 من أصل 0 سجل",
                    infoFiltered: "(منتقاة من مجموع _MAX_ مُدخل)",
                    infoPostFix: "",
                    search: "ابحث:",
                    url: "",
                    paginate: {
                        first: "الأول",
                        previous: "السابق",
                        next: "التالي",
                        last: "الأخير"
                    }
                },
                initComplete: function(settings, json) {
                    console.log("Data received from the server:", json);
                }
            });


            $('.filter-button').click(function() {
                var filter = $(this).val();
                var startDate = $('#startDate').val();
                var endDate = $('#endDate').val();

                // Send an AJAX request to the server
                $.ajax({
                    type: 'get',
                    url: '/sales-discount-day',
                    data: {
                        filter: filter,
                        startDate: startDate,
                        endDate: endDate,
                        _token: '{{ csrf_token() }}'
                    },
                    dataType: 'json', // Ensure the dataType is set to 'json' to parse the JSON response
                    success: function(response) {
                        table1.clear();

                        // Check if response has 'data' property and is an array
                        if (response.data && Array.isArray(response.data)) {
                            // Add the new data to the table and redraw
                            table1.rows.add(response.data).draw();

                            console.log("Response data:", response);
                            console.log("DataTable instance:", table1);
                        } else {
                            console.log("Response data is invalid:", response);
                        }
                    },
                    error: function(error) {
                        console.log('Error:', error);
                    }
                });
            });

        });
    </script>
@endsection
