<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الوافي</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/vendors/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/pages/auth.css">
</head>


<body>
    <div id="auth">

        <div class="row h-100" style="display: flex;justify-content: center;text-align: right;">
            <div class="col-lg-8 col-md-12 col-sm-12" style=" margin: auto;">
                <a class="d-flex" href="{{ route('login') }}" style="justify-content: flex-end;">
                    <h1>الوافي</h1>
                    <img src="{{ asset('icon.ico') }}" alt="Logo" srcset=""
                        style=" height:50px ; width: 50px; align-items: center;">
                </a>
                <div style=" padding: 20px">
                    <div class="auth-logo mb-5">
                    </div>
                    <h1 class="auth-title">تسجيل الدخول</h1>
                    <p class="auth-subtitle mb-5">تسجيل الدخول باستخدام البيانات التي أدخلتها أثناء التسجيل</p>


                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="text" class="form-control form-control-xl"type="email" name="email"
                                value="{{ old('email') }}" required autofocus autocomplete="username"
                                placeholder="الاميل">
                            <div class="form-control-icon">
                                <i class="bi bi-person"></i>
                            </div>
                        </div>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="password" class="form-control form-control-xl" type="password" name="password"
                                required autocomplete="current-password" placeholder="كلمة المرور">
                            <div class="form-control-icon">
                                <i class="bi bi-shield-lock"></i>
                            </div>
                        </div>
                        <div class="form-check form-check-lg d-flex align-items-end">
                            <input class="form-check-input me-2" type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label text-gray-600" for="flexCheckDefault">
                                تذكراني
                            </label>
                        </div>
                        <button class="btn btn-primary btn-block btn-lg shadow-lg mt-5">دخول</button>
                    </form>
                    <div class="text-center mt-5 text-lg fs-4">
                        <p class="text-gray-600"> انشاء حساب جديد<a href="{{ route('register') }}" class="font-bold">
                                تسجيل
                            </a>.</p>
                        {{-- <p><a class="font-bold" href="auth-forgot-password.html">Forgot password?</a>.</p> --}}
                    </div>
                </div>
            </div>

        </div>

    </div>
</body>

</html>
