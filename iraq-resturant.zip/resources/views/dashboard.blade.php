@extends('layouts.master')
@section('content')
    <style>
        .notification-card {
            background-color: #f8d7da;
            /* Set your desired background color for notifications */
            /* border: 1px solid #dc3545; */
            /* Set your desired border color */
            border-radius: 5px;
            /* Adjust border radius as needed */
            /* box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); */
            background-color: #fff;
            /* Optional box shadow */
        }

        .notification-icon {
            background-color: #dc3545;
            /* Set the background color for the notification icon */
            color: #fff;
            /* Set the icon color */
            width: 40px;
            /* Adjust the icon container width */
            height: 40px;
            /* Adjust the icon container height */
            border-radius: 50%;
            /* Make the container a circle for a notification effect */
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px;

        }

        /* Set the icon size */
        }
    </style>
    <div id="main">
        <header class="mb-3">
            <a href="#" class="burger-btn d-block d-xl-none">
                <i class="bi bi-justify fs-3"></i>
            </a>
        </header>

        <div class="page-heading">
            <h3 style="text-align: end;">أخر الإحصائيات</h3>
        </div>

        <div class="filters">
            <form action="">
                <div class="btn" style="display: contents;" role="group" aria-label="Basic example">
                    <button class="filter-button  btn-sm btn-secondary" name="day" value="day">اليوم</button>
                    <button class="filter-button btn-sm  btn-secondary" name="yesterday" value="yesterday">الامس</button>
                    <button class="filter-button btn-sm  btn-secondary" name="week" value="week">الاسبوع</button>
                    <button class="filter-button btn-sm  btn-secondary" name="month" value="month">الشهر </button>
                    <button class="filter-button btn-sm btn-secondary" name="year" value="year">السنه</button>
                </div>
            </form>
        </div>
        <div class="page-content">
            <section class="row"></section>
            <div class="row">
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="stats-icon purple">
                                        <i class="iconly-boldShow"></i>
                                    </div>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h6 class="text-muted font-semibold"> صافي المبيعات</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ number_format($userData->sum('net')) }}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon blue">
                                        <i class="iconly-boldProfile"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> المبيعات</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ number_format($userData->sum('TotalSales')) }}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon red">
                                        <i class="iconly-boldBookmark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> المصروفات</h6>
                                    <h6 class="font-extrabold mb-0"> {{ number_format($userData->sum('ExpencValue')) }}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon red">
                                        <i class="iconly-boldBookmark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> الخصومات</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ $total3 = number_format($userData->sum('Discount')) }}</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card notification-card">
                        <div class="card-body px-3 py-4-5" style="position: relative;">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="notification-icon">
                                        <i class="iconly-boldBookmark"></i>
                                        <span class="notification-count"
                                            style="  position: absolute;
                                        top: 19px;
                                        left: 51px;
                                        color: red;">{{ $userData->sum('NoSafery') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> سفري</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ $total1 = number_format($userData->sum('TotalSafery')) }}
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card notification-card">
                        <div class="card-body px-3 py-4-5" style="position: relative;">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="notification-icon">
                                        <i class="iconly-boldBookmark"></i>
                                        <span class="notification-count"
                                            style="  position: absolute;
                                        top: 19px;
                                        left: 51px;
                                        color: red;">{{ $userData->sum('NoDlivery') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> ديلفري</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ $total2 = number_format($userData->sum('TotalDlivery')) }}
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card notification-card">
                        <div class="card-body px-3 py-4-5" style="position: relative;">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="notification-icon">
                                        <i class="iconly-boldBookmark"></i>
                                        <span class="notification-count"
                                            style="  position: absolute;
                                        top: 19px;
                                        left: 51px;
                                        color: red;">{{ $userData->sum('NoTabel') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> طاولة</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ $total3 = number_format($userData->sum('TotalTabel')) }}
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card notification-card">
                        <div class="card-body px-3 py-4-5" style="position: relative;">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="notification-icon">
                                        <i class="iconly-boldBookmark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold"> الطلبات</h6>
                                    <h6 class="font-extrabold mb-0">
                                        {{ $userData->sum(function ($item) {
                                            return $item->NoSafery + $item->NoTabel + $item->NoDlivery;
                                        }) }}
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <div class="col-12 col-lg-12">


                <style>
                    /* For screens with a maximum width of 400px */
                    @media (max-width: 400px) {
                        .chart, .chartc {
                            max-width: 400px; /* Set the maximum width */
                            width: 100%; /* Maintain a full-width appearance */
                            height: 500px !important; /* Adjust the height as needed */
                        }
                    }
                    </style>
                    

                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>تغيير المبيعات</h4>
                            </div>
                            <div class="card-body">
                                <div class="chart">
                                    <canvas class="chartc" id="Chart1"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>الرسم التوضيحي للمصروفات</h4>
                            </div>
                            <div class="card-body">
                                <div class="chart">
                                    <canvas class="chartc" id="Chart2"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>ملخص مبيعات المستخدمين</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-lg">
                                        <thead>
                                            <tr>
                                                <th style="white-space: nowrap;">اسم المستخدم </th>
                                                <th>الصافي</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($userData as $date)
                                                <tr>
                                                    <td class="col-3">
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar avatar-md">
                                                                <img src="assets/images/faces/2.jpg">
                                                            </div>
                                                            <p class="font-bold ms-3 mb-0">{{ $date->UserName }}</p>
                                                        </div>
                                                    </td>
                                                    <td class="col-auto">
                                                        <p class=" mb-0">{{ number_format($date->net) }}</p>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-12 col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>مبيعات شركات التوصيل </h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-lg">
                                        <thead>
                                            <tr>
                                                <th style="white-space: nowrap;">  طلبات التوصيل</th>
                                                <th style="white-space: nowrap;">  المبلغ المباع</th>
                                                <th style="white-space: nowrap;"> الفواتير</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($results as $sales)
                                                <tr>
                                                    <td class="col-auto">
                                                        <p class=" mb-0">{{ $sales->dilvery_type }}</p>
                                                    </td>
                                                    <td class="col-auto">
                                                        <p class=" mb-0">
                                                            {{ number_format($sales->total) }}
                                                        </p>
                                                    </td>
                                                    <td class="col-auto">
                                                        <p class=" mb-0">{{ $sales->amount }}</p>
                                                    </td>
                                                </tr>
                                            @empty
                                                no data
                                            @endforelse

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            </section>
        </div>

        @include('layouts.footer')
    </div>
@endsection
@section('chart')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Get the canvas element
        var ctx = document.getElementById('Chart1').getContext('2d');

        // Define the data for the chart
        var data = {
            labels: ['سفري', 'ديلفري', 'طاوله'],
            datasets: [{
                label: 'Sales Change',
                data: [{{ $total1 }}, {{ $total2 }}, {{ $total3 }}],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)', // Color for the first segment
                    'rgba(255, 99, 132, 0.2)', // Color for the second segment
                    'rgba(54, 162, 235, 0.2)' // Color for the third segment
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)', // Border color for the first segment
                    'rgba(255, 99, 132, 1)', // Border color for the second segment
                    'rgba(54, 162, 235, 1)' // Border color for the third segment
                ],
                borderWidth: 1 // Border width for all segments
            }]
        };

        // Create the chart
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                // Additional options for customizing your chart
            }
        });
    </script>

    {{-- ------------------------------table same hegiht ------------------------------------------------ --}}
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Get the heights of both tables
            var table1Height = $('.table-responsive:eq(0)').height();
            var table2Height = $('.table-responsive:eq(1)').height();

            // Set both tables to the height of the taller one
            var tallerHeight = Math.max(table1Height, table2Height);
            $('.table-responsive:eq(0)').height(tallerHeight);
            $('.table-responsive:eq(1)').height(tallerHeight);
        });
    </script>
    {{-- -------------------------------notivication------------------------------- --}}
    {{-- <script>
    // Example: Update the notification count dynamically
    var notificationCount = 10; // Set your dynamic count
    var notificationCountElement = document.querySelector('.notification-count');
    notificationCountElement.textContent = notificationCount;
</script> --}}
    {{-- -------------------------------notivication------------------------------- --}}

    <script>
        // Get the canvas elements by ID
        var salesChartCanvas = document.getElementById('Chart1');
        var myDoughnutChartCanvas = document.getElementById('myDoughnutChart');

        // Get the computed height of the first canvas
        var salesChartHeight = getComputedStyle(salesChartCanvas).height;

        // Set the same height for the second canvas
        myDoughnutChartCanvas.style.height = salesChartHeight;
    </script>
    {{-- ------------------------------repot  buy ------------------------------------------------ --}}
    <script>
        var buys = <?php echo json_encode($buys); ?>; // Pass your PHP array

        var accountNames = buys.map(function(item) {
            return item.AccountName;
        });

        var values = buys.map(function(item) {
            return parseFloat(item.Value);
        });

        var ctx = document.getElementById('Chart2').getContext('2d');

        var chart = new Chart(ctx, {
            type: 'line', // Use a line chart
            data: {
                labels: accountNames, // Labels for each data point
                datasets: [{
                    label: 'Value',
                    data: values, // Data points
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            }
        });
    </script>
@endsection
